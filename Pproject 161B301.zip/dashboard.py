#---------USER DASHBOARD--------------
from Tkinter import *
import  requests
from tkMessageBox import *
#from PIL import ImageTk, Image


def user_verify(usr_data,db,connection):
    def verify():
        if not ev.get():
            showwarning("Warning","Input field should not be empty")

        elif str(usr_data[0][5]) == str(ev.get()) :
                db.execute("update students_tab set otp = 'yes' where eid='"+str(usr_data[0][0])+"'")
                connection.commit()
                showinfo("Success","Verification Successfully Done , Now Login Again !!")
                ver.destroy()
        else:
            showerror("Error","Invalid OTP Entered,Please Try Again with Correct OTP !!")

    ver = Tk()
    ver.title("User Verification")
    ver.iconbitmap('logo.ico')
    Label(ver,text="Verify Your Account , Please Enter Received OTP here :-",bg="#f48342",relief='ridge',bd=6).grid(pady=8)
    ev = Entry(ver,bd=2)
    ev.grid(pady=10)
    Button(ver,text="Verify",bd=2,command=verify).grid(pady=10)


def user_dash(usr_data):
    def cilent_options():
        if cilent.get() == str(options_cilent[1]) :
            if askquestion("Logout", "Do You want to Logout ?") == "yes":
                dash.destroy()
                showinfo("Logout Message", str(usr_data[0][0]) + ", You Are Successfully Logout !!")
        else:
            showwarning("Error", "Please Select Valid Options")

    def hostel_services():
        def exit_portal():
            op.destroy()
        def get_outpass():
            if not usr_data[0][0] and not l_date.get() and not j_date.get() and not l_time.get() and not j_time.get() and not usr_data[0][4] and not p_email.get() and not p_contact.get() and not place.get():
                showwarning("Warning", "Please Fill the form correctly ")
            else:
                headers = {'User-Agent': 'Mozilla/5.0'}
                payload = {'e_id': str(usr_data[0][0]), 'l_date': str(l_date.get()), 'j_date': str(j_date.get()), 'l_time': str(l_time.get()),
                           'j_time': str(j_time.get()), 's_email': str(usr_data[0][4]), 'p_email': str(p_email.get()),
                           'p_contact': str(p_contact.get()), 'visit_place': str(place.get())}
                session = requests.Session()
                re = session.post('https://sushantsoftwares.121wh.in/op', headers=headers, data=payload)
                if re :
                    showinfo("Success","Your Request Has been Successfully Submitted , Please Check Your Email id for Step 1 Verification")
                print re.status_code
        if variable.get() == str(options[0]):
            op = Tk()
            op.title("Online Outpass Portal")
            op.configure(bg="#00c6c3")
            op.iconbitmap('logo.ico')
            Label(op,text="Fill Your Valid Details",bg="white",relief='ridge',bd=5,fg="black",font="times 23 bold").grid(pady=4)
            Label(op,text="Your Enrollement Number :-  "+str(usr_data[0][0]),font="times 15 bold").grid(pady=2)
            Label(op,text="Leaving Date (YYYY-MM-DD):-",relief='ridge',bd=3).grid(pady=2)
            l_date = Entry(op,bd=3)
            l_date.grid(pady=2)
            Label(op, text="Joining Date (YYYY-MM-DD):-", relief='ridge', bd=3).grid(pady=2)
            j_date = Entry(op, bd=3)
            j_date.grid(pady=2)
            Label(op, text="Leaving Time (HR:MM):-", relief='ridge', bd=3).grid(pady=2)
            l_time = Entry(op, bd=3)
            l_time.grid(pady=2)
            Label(op, text="Joining Time (HR:MM):-", relief='ridge', bd=3).grid(pady=2)
            j_time = Entry(op, bd=3)
            j_time.grid(pady=2)
            Label(op, text="Your Email id is :-  "+str(usr_data[0][4]), relief='ridge',font="times 15 bold",bg="red", bd=3).grid(pady=2)
            Label(op, text="Parents Email id :-", relief='ridge', bd=3).grid(pady=2)
            p_email = Entry(op, bd=3)
            p_email.grid(pady=2)
            Label(op, text="Parents Contact Number :-", relief='ridge', bd=3).grid(pady=2)
            p_contact = Entry(op, bd=3)
            p_contact.grid(pady=2)
            Label(op, text="Visiting Place (eg: New Delhi) :-", relief='ridge', bd=3).grid(pady=2)
            place = Entry(op, bd=3)
            place.grid(pady=4)
            Button(op,text="Submit For Approval",bd=4,command=get_outpass).grid(pady=2)
            Button(op,text="Exit OP Portal",bd=4,command=exit_portal).grid()
        else:
            showwarning("Error","Please Select Valid Options")

    dash = Tk()
    dash.title("User Dashboard")
    dash.iconbitmap('logo.ico')
    dash.configure(bg="#6830a5")
    dash.geometry("800x400")

    cilent = StringVar(dash)
    cilent.set("Welcome "+str(usr_data[0][0]))
    options_cilent = list(["Update Profile Details", "Logout","About Developer"])
    OptionMenu(dash,cilent, *(options_cilent)).grid(row=0, column=6)
    Button(dash,text="Click",bd=5,command=cilent_options).grid(row=0,column=8)


    Label(dash,text=str(usr_data[0][0])+" Dashboard",relief='ridge',font="times 20 bold",fg="white",bd=10,bg="#4242f4").grid(row=0,column=5)

    Label(dash,text="Select Portal Services",relief='ridge',font="times 10 bold",bd=8,bg="#f4e842").grid(row=3,column=5)
    variable = StringVar(dash)
    variable.set("Please Select Your Option")
    options = list(["Online Outpass","Hostel Attendance"])
    OptionMenu(dash,variable,*(options)).grid(row=3,column=6)
    Button(dash,text="Proceed",bd=5,command=hostel_services).grid(row=3,column=8,pady=18,padx=19)





