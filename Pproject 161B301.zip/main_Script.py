from Tkinter import *
import  sqlite3
from tkMessageBox import  *
from datetime import  *
from validate_email import *
import random
from dashboard import *
from PIL import ImageTk, Image
import os

today = date.today()

con = sqlite3.Connection('studentdb')
cur = con.cursor()

main = Tk()
main.title("Jaypee University of Engineering And Technology")
main.geometry("1000x570")
main.configure(bg="#6da7c6")
img = ImageTk.PhotoImage(Image.open("a.png")) 
#img = PhotoImage("a.gif")
imglabel = Label(main, image=img).grid(row=0, column=0,sticky=W,pady=30,padx=10)
main.iconbitmap('logo.ico')

def send_email(otp,email):
    headers = {'User-Agent': 'Mozilla/5.0'}
    payload = {'u_email':str(email),'u_otp':str(otp),'enroll_id':str(e.get())}
    session = requests.Session()
    re=session.post('https://sushantsoftwares.121wh.in/python_email.php',headers=headers,data=payload)
    re
    print re.text



def exit_win():
    if askquestion("Quit Portal","Do You want to Exit ?") == "yes":
        main.destroy()

def register_usr():
    def exit_reg():
        if askquestion("Quit", "Do You want to Exit ?") == "yes":
            reg_win.destroy()

    def submit_reg_form():

        if askquestion("Submit Form", "Do You want to Submit ?") == "yes":
            if e.get() and e1.get() and e2.get() and e3.get() and e4.get() and e5.get():
                cur.execute("create table if not exists students_tab (eid varchar(20) PRIMARY KEY,password varchar(100) NOT NULL,hostel varchar(10),room_no varchar(10),email varchar(10) UNIQUE NOT NULL,otp varchar(7) DEFAULT '0',log_status int DEFAULT '0')")
                c = list(cur.execute("select count(*) from students_tab where eid='"+str(e.get())+"' or email='"+str(e5.get())+"'"))
                if str(c[0][0]) == "0" :
                    if e1.get() == e2.get() :
                        if validate_email(str(e5.get())):
                            x = random.randint(0, 999999)
                            print x
                            if(cur.execute("insert into students_tab  values('"+str(e.get())+"','"+str(e1.get())+"','"+str(e3.get())+"','"+str(e4.get())+"','"+str(e5.get())+"','"+str(x)+"','0')")):
                             con.commit()
                             showinfo("success","Registration Successfully Completed , OTP send Successfully to Your Email-id ")
                             send_email(x,e5.get())
                             reg_win.destroy()
                        else:
                            showerror("Error","Check The Details Correctly")
                    else:
                       showwarning("Warning", "Password Doesn't match")
                else:
                    showwarning("warning","User Already Registered !!")
            else:
                showerror("Error", "Please Fill the Form Details Completely")



    reg_win = Tk()
    reg_win.title("Student Registration")
    Label(reg_win, text="Register Yourself", relief="ridge", bg="Green", font="times 20 bold", width=50, bd=10,
          justify='right').grid(row=0, column=0)
    Label(reg_win, text="Enrollment Number:- ", font="times 15 bold",height=1).grid(row=2, column=0,padx=10)
    e = Entry(reg_win)
    e.grid(row=2, column=1)

    Label(reg_win, text="Password:- ", font="times 15 bold",height=1).grid(row=4, column=0,padx=10)
    e1 = Entry(reg_win, show="*")
    e1.grid(row=4, column=1)

    Label(reg_win, text="Confirm Password:- ", font="times 15 bold",height=1).grid(row=6, column=0)
    e2 = Entry(reg_win, show="*")
    e2.grid(row=6, column=1)

    Label(reg_win, text="Hostel:- ", font="times 15 bold",height=1).grid(row=8, column=0)
    e3 = Entry(reg_win)
    e3.grid(row=8, column=1)

    Label(reg_win, text="Room No:- ", font="times 15 bold",height=1).grid(row=10, column=0)
    e4 = Entry(reg_win)
    e4.grid(row=10, column=1)

    Label(reg_win, text="Email-id:- ", font="times 15 bold",height=1).grid(row=12, column=0)
    e5 = Entry(reg_win)
    e5.grid(row=12, column=1)

    Button(reg_win, text="Exit", bd=2,command=exit_reg).grid(row=13, column=0)
    Button(reg_win, text="Submit", bd=2,command=submit_reg_form).grid(row=13, column=1)

def login_usr():
    if not e.get() or not e1.get():
            showwarning("Warning","Input Fields should not be Empty")

    else :
        login_data=list(cur.execute("select * from students_tab where eid='"+str(e.get())+"'"))
        if not login_data:
                    showerror("Error","No Such User Found")
        elif login_data[0][0] == e.get() and login_data[0][1] == e1.get() or int(login_data[0][6]) == 0:
            cur.execute("update students_tab set log_status='1' where eid='"+str(e.get())+"'")
            showinfo("Success","Logged in Successfully !!")
            c = list(cur.execute("select count(*) from students_tab where otp='yes' and eid='" + str(e.get()) + "'"))
            if str(c[0][0]) != "1" :
                user_verify(login_data,cur,con)

            elif str(c[0][0]) == "1" :
                showinfo("Data","Welcome "+str(login_data[0][0]))
                
                user_dash(login_data)
        else:
            showerror("Login Error","Login Failed !!")

def clear():
    e.delete(0,END)
    e1.delete(0,END)

# main section for Program ------------------

Label(main,text="JUET Hostel Portal "+str(today),relief="ridge",bg="#3340b7",fg="white",font="times 20 bold",width=30,bd=10).grid(sticky=W+E+N+S,pady=30,row=0,column=1)

Label(main,text="Enrollment Number:- ",font="times 15 bold",width=30,height=4,bg="#cced49").grid(row=2,column=0)
e = Entry(main,width=26)
e.grid(row=2,column=1)

Label(main,text="Password:- ",font="times 15 bold",width=30,height=4,bg="#cced49").grid(row=4,column=0)
e1 = Entry(main,show="*",fg="white",width=26)
e1.grid(row=4,column=1)


Button(main,text="Login",width=10,bd=7,command=login_usr).grid(row=6,column=1,pady=10)
Button(main,text="Exit",width=10,bd=7,command=exit_win).grid(row=6,column=0,pady=10,sticky=W,padx=10)
Button(main,text="Register",width=10,bd=7,command=register_usr).grid(row=6,column=2)
Button(main,text="Reset",width=10,bd=7,command=clear).grid(row=6,column=0,columnspan=6)

main.mainloop()
