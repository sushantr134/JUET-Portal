import requests
from tkMessageBox import *


def get_outpass(eid,ldate,jdate,ltime,jtime,stdemail,pemail,pcontact,visitplace):
    if not eid and not ldate and not jdate and not ltime and not jtime and not stdemail and not pemail and not pcontact and not pcontact and not visitplace:
        showwarning("Warning","Please Fill the form correctly ")
    else:
        headers = {'User-Agent': 'Mozilla/5.0'}
        payload = {'e_id':str(eid),'l_date':str(ldate),'j_date':str(jdate),'l_time':str(ltime),'j_time':str(jtime),'s_email':str(stdemail),'p_email':str(pemail),'p_contact':str(pcontact),'visit_place':str(visitplace)}
        session = requests.Session()
        re=session.post('https://sushantsoftwares.121wh.in/op',headers=headers,data=payload)
        re
        print re.text



